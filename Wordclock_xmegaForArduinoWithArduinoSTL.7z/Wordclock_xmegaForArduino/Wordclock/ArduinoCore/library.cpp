/*
 * ArduinoCore.cpp
 *
 * Created: 2017-06-22 14:25:37
 * Author : virskl
 */ 

#include <avr/io.h>


/* Replace with your library code */
int myfunc(void)
{
	return 0;
}

